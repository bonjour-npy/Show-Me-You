package com.example.photoshare.postentity;

public class FaBu {
    public String content;
    public int id;
    public double imageCode;
    public double pUserId;
    public String title;

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public double getImageCode() {
        return imageCode;
    }

    public void setImageCode(double imageCode) {
        this.imageCode = imageCode;
    }

    public double getpUserId() {
        return pUserId;
    }

    public void setpUserId(double pUserId) {
        this.pUserId = pUserId;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }
}
