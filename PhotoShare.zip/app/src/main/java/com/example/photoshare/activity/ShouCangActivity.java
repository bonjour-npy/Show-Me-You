package com.example.photoshare.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.photoshare.R;

public class ShouCangActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_shou_cang);
    }
}