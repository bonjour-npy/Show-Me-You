package com.example.photoshare.activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.photoshare.R;

public class GuanZhuActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_guan_zhu);
    }
}